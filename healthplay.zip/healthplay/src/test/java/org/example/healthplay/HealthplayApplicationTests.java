package org.example.healthplay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthplayApplicationTests {

    @Test
    void contextLoads() {
    }

}
