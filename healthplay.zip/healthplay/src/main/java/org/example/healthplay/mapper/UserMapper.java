package org.example.healthplay.mapper;
//定义操作用户表数据的接口，声明用户相关的数据库操作方法，

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.example.healthplay.entity.User;

import java.util.List;

@Mapper
public interface UserMapper {
    User findByUsername(@Param("username") String username);
    List<User> getAllUser(@Param("username") String username,
                          @Param("pageStart") int pageStart,
                          @Param("pageSize") int pageSize);
    int getUserCounts(@Param("username") String username);
    int updateState(Integer id, Boolean state);
    int addUser(User user);
    User getUpdateUser(int id);
    int editUser(User user);
    int deleteUser(int id);
    int setUserRole(@Param("id") Integer id, @Param("role") String role);
}