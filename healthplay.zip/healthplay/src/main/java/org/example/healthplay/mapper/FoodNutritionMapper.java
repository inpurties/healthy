package org.example.healthplay.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.example.healthplay.entity.FoodNutrition;
import java.util.List;

@Mapper
public interface FoodNutritionMapper {

    @Select("SELECT * FROM food_nutrition WHERE food_name LIKE CONCAT('%', #{foodName}, '%')")
    List<FoodNutrition> findByFoodNameLike(@Param("foodName") String foodName);

    @Select("SELECT * FROM food_nutrition WHERE food_name = #{foodName}")
    FoodNutrition findByFoodName(@Param("foodName") String foodName);

    @Select("SELECT * FROM food_nutrition WHERE food_category = #{category}")
    List<FoodNutrition> findByCategory(@Param("category") String category);

    @Select("SELECT * FROM food_nutrition")
    List<FoodNutrition> findAll();
}