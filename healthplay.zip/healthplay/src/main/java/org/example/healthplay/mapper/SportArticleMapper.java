package org.example.healthplay.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.example.healthplay.entity.SportArticle;

import java.util.List;

@Mapper
public interface SportArticleMapper {

    List<SportArticle> getPublishedArticles(@Param("categoryId") Integer categoryId,
                                          @Param("pageStart") int pageStart,
                                          @Param("pageSize") int pageSize);

    int getPublishedArticleCount(@Param("categoryId") Integer categoryId);

    SportArticle getArticleById(@Param("id") Long id);

    List<SportArticle> getFeaturedArticles(@Param("limit") int limit);

    List<SportArticle> searchArticlesByTag(@Param("tag") String tag,
                                          @Param("pageStart") int pageStart,
                                          @Param("pageSize") int pageSize);

    // 新增文章
    int insertArticle(SportArticle article);

    // 更新文章
    int updateArticle(SportArticle article);

    // 删除文章
    int deleteArticle(@Param("id") Long id);

    // 增加浏览量
    int increaseViewCount(@Param("id") Long id);

    // 增加点赞数
    int increaseLikeCount(@Param("id") Long id);
}