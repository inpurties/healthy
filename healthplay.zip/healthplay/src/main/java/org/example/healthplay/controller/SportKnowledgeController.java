package org.example.healthplay.controller;

import org.example.healthplay.entity.SportCategory;
import org.example.healthplay.entity.SportArticle;
import org.example.healthplay.service.SportCategoryService;
import org.example.healthplay.service.SportArticleService;
import org.example.healthplay.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/sport-knowledge")
public class SportKnowledgeController {

    @Autowired
    private SportCategoryService sportCategoryService;

    @Autowired
    private SportArticleService sportArticleService;

    // 获取所有分类
    @GetMapping("/categories")
    public Result getCategories() {
        try {
            List<SportCategory> categories = sportCategoryService.getAllActiveCategories();
            return Result.success("获取分类成功", categories);
        } catch (Exception e) {
            return Result.error("获取分类失败: " + e.getMessage());
        }
    }

    // 根据父分类ID获取子分类
    @GetMapping("/categories/children/{parentId}")
    public Result getCategoriesByParentId(@PathVariable Long parentId) {
        try {
            List<SportCategory> categories = sportCategoryService.getCategoriesByParentId(parentId.intValue());
            return Result.success("获取子分类成功", categories);
        } catch (Exception e) {
            return Result.error("获取子分类失败: " + e.getMessage());
        }
    }

    // 分页获取文章列表
    @GetMapping("/articles")
    public Result getArticles(@RequestParam(defaultValue = "1") Integer pageNum,
                            @RequestParam(defaultValue = "10") Integer pageSize,
                            @RequestParam(required = false) Long categoryId) {
        try {
            Map<String, Object> result = sportArticleService.getPublishedArticles(
                categoryId != null ? categoryId.intValue() : null, 
                pageNum, 
                pageSize
            );
            return Result.success("获取文章列表成功", result);
        } catch (Exception e) {
            return Result.error("获取文章列表失败: " + e.getMessage());
        }
    }

    // 获取文章详情
    @GetMapping("/articles/{id}")
    public Result getArticleDetail(@PathVariable Long id) {
        try {
            SportArticle article = sportArticleService.getArticleById(id);
            if (article != null) {
                return Result.success("获取文章详情成功", article);
            } else {
                return Result.error("文章不存在");
            }
        } catch (Exception e) {
            return Result.error("获取文章详情失败: " + e.getMessage());
        }
    }

    // 获取推荐文章
    @GetMapping("/articles/featured")
    public Result getFeaturedArticles(@RequestParam(defaultValue = "5") Integer limit) {
        try {
            List<SportArticle> featuredArticles = sportArticleService.getFeaturedArticles(limit);
            return Result.success("获取推荐文章成功", featuredArticles);
        } catch (Exception e) {
            return Result.error("获取推荐文章失败: " + e.getMessage());
        }
    }

    // 根据标签搜索文章
    @GetMapping("/articles/search")
    public Result searchArticles(@RequestParam String tag,
                               @RequestParam(defaultValue = "1") Integer pageNum,
                               @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Map<String, Object> result = sportArticleService.searchArticlesByTag(tag, pageNum, pageSize);
            return Result.success("搜索文章成功", result);
        } catch (Exception e) {
            return Result.error("搜索文章失败: " + e.getMessage());
        }
    }

    // 文章点赞
    @PostMapping("/articles/{id}/like")
    public Result likeArticle(@PathVariable Long id) {
        try {
            boolean success = sportArticleService.increaseLikeCount(id);
            if (success) {
                return Result.success("点赞成功", null);
            } else {
                return Result.error("点赞失败");
            }
        } catch (Exception e) {
            return Result.error("点赞失败: " + e.getMessage());
        }
    }
}