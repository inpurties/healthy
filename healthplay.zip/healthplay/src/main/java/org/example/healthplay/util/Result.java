package org.example.healthplay.util;

public class Result {
    private int code; // 状态码，比如 200 成功、500 失败等
    private String msg; // 提示信息
    private Object data; // 返回的数据

    // 私有构造方法，避免直接 new，通过静态方法创建实例
    private Result(int code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    // Getter and Setter methods
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    // 成功时的静态方法
    public static Result success(String msg, Object data) {
        return new Result(200, msg, data);
    }

    // 失败时的静态方法
    public static Result error(String msg) {
        return new Result(500, msg, null);
    }

    // 如果需要，还可以扩展其他方法，比如带自定义状态码的失败方法
    public static Result error(int code, String msg) {
        return new Result(code, msg, null);
    }
}