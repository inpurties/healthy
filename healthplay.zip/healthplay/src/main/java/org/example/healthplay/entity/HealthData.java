package org.example.healthplay.entity;

import java.time.LocalDateTime;

public class HealthData {
    private Long id;
    private Integer userId;
    private Integer stepCount;
    private Integer stepGoal;
    private Integer calorie;
    private Integer calorieFromExercise;
    private Double sleepHours;
    private Double deepSleepHours;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    // Getter and Setter methods
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getStepCount() {
        return stepCount;
    }

    public void setStepCount(Integer stepCount) {
        this.stepCount = stepCount;
    }

    public Integer getStepGoal() {
        return stepGoal;
    }

    public void setStepGoal(Integer stepGoal) {
        this.stepGoal = stepGoal;
    }

    public Integer getCalorie() {
        return calorie;
    }

    public void setCalorie(Integer calorie) {
        this.calorie = calorie;
    }

    public Integer getCalorieFromExercise() {
        return calorieFromExercise;
    }

    public void setCalorieFromExercise(Integer calorieFromExercise) {
        this.calorieFromExercise = calorieFromExercise;
    }

    public Double getSleepHours() {
        return sleepHours;
    }

    public void setSleepHours(Double sleepHours) {
        this.sleepHours = sleepHours;
    }

    public Double getDeepSleepHours() {
        return deepSleepHours;
    }

    public void setDeepSleepHours(Double deepSleepHours) {
        this.deepSleepHours = deepSleepHours;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}