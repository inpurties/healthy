package org.example.healthplay.service.impl;

import org.example.healthplay.entity.SportArticle;
import org.example.healthplay.mapper.SportArticleMapper;
import org.example.healthplay.service.SportArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SportArticleServiceImpl implements SportArticleService {

    @Autowired
    private SportArticleMapper sportArticleMapper;

    @Override
    public Map<String, Object> getPublishedArticles(Integer categoryId, int pageNum, int pageSize) {
        int pageStart = (pageNum - 1) * pageSize;
        List<SportArticle> articles = sportArticleMapper.getPublishedArticles(categoryId, pageStart, pageSize);
        int total = sportArticleMapper.getPublishedArticleCount(categoryId);
        
        Map<String, Object> result = new HashMap<>();
        result.put("articles", articles);
        result.put("total", total);
        result.put("pageNum", pageNum);
        result.put("pageSize", pageSize);
        
        return result;
    }

    @Override
    public SportArticle getArticleById(Long id) {
        return sportArticleMapper.getArticleById(id);
    }

    @Override
    public List<SportArticle> getFeaturedArticles(int limit) {
        return sportArticleMapper.getFeaturedArticles(limit);
    }

    @Override
    public Map<String, Object> searchArticlesByTag(String tag, int pageNum, int pageSize) {
        int pageStart = (pageNum - 1) * pageSize;
        List<SportArticle> articles = sportArticleMapper.searchArticlesByTag(tag, pageStart, pageSize);
        
        Map<String, Object> result = new HashMap<>();
        result.put("articles", articles);
        result.put("tag", tag);
        result.put("pageNum", pageNum);
        result.put("pageSize", pageSize);
        
        return result;
    }

    @Override
    public boolean addArticle(SportArticle article) {
        return sportArticleMapper.insertArticle(article) > 0;
    }

    @Override
    public boolean updateArticle(SportArticle article) {
        return sportArticleMapper.updateArticle(article) > 0;
    }

    @Override
    public boolean deleteArticle(Long id) {
        return sportArticleMapper.deleteArticle(id) > 0;
    }

    @Override
    public boolean increaseViewCount(Long id) {
        return sportArticleMapper.increaseViewCount(id) > 0;
    }

    @Override
    public boolean increaseLikeCount(Long id) {
        return sportArticleMapper.increaseLikeCount(id) > 0;
    }
}