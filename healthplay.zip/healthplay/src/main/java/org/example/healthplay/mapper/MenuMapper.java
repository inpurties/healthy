package org.example.healthplay.mapper;
//处理菜单相关的请求，获取菜单列表、菜单新增 / 修改 / 删除的请求接收与响应，
// 调用业务层完成菜单数据的处理，再把结果返回给前端 。
import org.apache.ibatis.annotations.Mapper; // 导入 MyBatis 的 @Mapper
import org.example.healthplay.entity.MainMenu;

import java.util.List;

@Mapper // 替换 @Repository，声明为 MyBatis Mapper
public interface MenuMapper {

    List<MainMenu> getMenuList(); // 获取菜单列表
}