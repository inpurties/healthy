package org.example.healthplay.service;

import org.example.healthplay.entity.FoodNutrition;
import org.example.healthplay.entity.UserFoodRecord;
import org.example.healthplay.mapper.FoodNutritionMapper;
import org.example.healthplay.mapper.UserFoodRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CalorieService {

    @Autowired
    private FoodNutritionMapper foodNutritionMapper;

    @Autowired
    private UserFoodRecordMapper userFoodRecordMapper;

    // 根据餐次和日期获取用户饮食记录
    public List<UserFoodRecord> getMealRecords(Integer userId, String mealType, LocalDate date) {
        List<UserFoodRecord> records = userFoodRecordMapper.findByUserIdAndDateAndMealType(userId, date, mealType);
        // 过滤掉null值，确保返回的数据都是有效的
        return records.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    // 获取用户每日营养统计
    public Map<String, Object> getDailyStats(Integer userId, LocalDate date) {
        return userFoodRecordMapper.getDailyStats(userId, date);
    }

    // 添加饮食记录
    public int addFoodRecord(UserFoodRecord record) {
        return userFoodRecordMapper.insert(record);
    }

    // 删除饮食记录
    public int deleteFoodRecord(Integer id) {
        return userFoodRecordMapper.deleteById(id);
    }

    // 搜索食物营养信息
    public List<FoodNutrition> searchFoods(String foodName) {
        List<FoodNutrition> foods = foodNutritionMapper.findByFoodNameLike(foodName);
        // 过滤掉null值
        return foods.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    // 根据食物名称获取营养信息
    public FoodNutrition getFoodNutrition(String foodName) {
        return foodNutritionMapper.findByFoodName(foodName);
    }

    // 获取所有食物营养信息
    public List<FoodNutrition> getAllFoods() {
        List<FoodNutrition> foods = foodNutritionMapper.findAll();
        // 过滤掉null值
        return foods.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    // 根据分类获取食物
    public List<FoodNutrition> getFoodsByCategory(String category) {
        List<FoodNutrition> foods = foodNutritionMapper.findByCategory(category);
        // 过滤掉null值
        return foods.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    // 更新饮食记录
    public int updateFoodRecord(UserFoodRecord record) {
        return userFoodRecordMapper.update(record);
    }

    // 获取用户某日所有饮食记录
    public List<UserFoodRecord> getDailyRecords(Integer userId, LocalDate date) {
        List<UserFoodRecord> records = userFoodRecordMapper.findByUserIdAndDate(userId, date);
        // 过滤掉null值
        return records.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
}