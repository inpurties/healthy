package org.example.healthplay.service;
//定义用户相关业务逻辑的接口，声明用户业务操作的方法，
import org.example.healthplay.entity.User;

public interface UserService {
    User login(String username, String password);
}
