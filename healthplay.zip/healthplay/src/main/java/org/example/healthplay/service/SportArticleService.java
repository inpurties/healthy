package org.example.healthplay.service;

import org.example.healthplay.entity.SportArticle;

import java.util.List;
import java.util.Map;

/**
 * 运动科普文章业务逻辑接口
 */
public interface SportArticleService {
    
    /**
     * 分页查询已发布的文章
     */
    Map<String, Object> getPublishedArticles(Integer categoryId, int pageNum, int pageSize);
    
    /**
     * 根据ID获取文章详情
     */
    SportArticle getArticleById(Long id);
    
    /**
     * 获取推荐文章
     */
    List<SportArticle> getFeaturedArticles(int limit);
    
    /**
     * 根据标签搜索文章
     */
    Map<String, Object> searchArticlesByTag(String tag, int pageNum, int pageSize);
    
    /**
     * 新增文章
     */
    boolean addArticle(SportArticle article);
    
    /**
     * 更新文章
     */
    boolean updateArticle(SportArticle article);
    
    /**
     * 删除文章
     */
    boolean deleteArticle(Long id);
    
    /**
     * 增加文章浏览次数
     */
    boolean increaseViewCount(Long id);
    
    /**
     * 增加文章点赞次数
     */
    boolean increaseLikeCount(Long id);
}