package org.example.healthplay;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("org.example.healthplay.mapper")
public class HealthplayApplication {

    public static void main(String[] args) {
        SpringApplication.run(HealthplayApplication.class, args);
    }

}
