package org.example.healthplay.controller;
//处理菜单相关的请求，获取菜单列表、菜单新增 / 修改 / 删除的请求接收与响应，
// 调用业务层完成菜单数据的处理，再把结果返回给前端 。
import org.example.healthplay.entity.MainMenu;
import org.example.healthplay.mapper.MenuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

@RestController // 添加此注解，标记为 Spring REST 控制器
@RequestMapping("/api") // 可选：添加基础路径
public class MenuController {

    @Autowired
    private MenuMapper menuMapper; // 注入 MenuMapper

    @RequestMapping("/menus") // 完整路径为 /api/menus
    public HashMap<String, Object> getAllMenus() {
        System.out.println("访问成功");
        HashMap<String, Object> data = new HashMap<>();
        List<MainMenu> menus = menuMapper.getMenuList(); // 修正方法调用，与 MenuMapper 接口保持一致
        if (menus != null && !menus.isEmpty()) { // 增加空集合判断
            data.put("menus", menus);
            data.put("flag", 200);
            data.put("message", "获取菜单成功"); // 可选：添加更详细的消息
        } else {
            data.put("flag", 404);
            data.put("message", "未找到菜单数据");
        }
        return data; // 直接返回 Map，Spring 会自动转换为 JSON
    }
}