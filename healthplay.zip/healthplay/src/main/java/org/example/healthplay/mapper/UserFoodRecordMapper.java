package org.example.healthplay.mapper;

import org.apache.ibatis.annotations.*;
import org.example.healthplay.entity.UserFoodRecord;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Mapper
public interface UserFoodRecordMapper {

    @Select("SELECT * FROM user_food_records WHERE user_id = #{userId} AND eat_date = #{eatDate} AND meal_type = #{mealType}")
    List<UserFoodRecord> findByUserIdAndDateAndMealType(@Param("userId") Integer userId, 
                                                        @Param("eatDate") LocalDate eatDate, 
                                                        @Param("mealType") String mealType);

    @Select("SELECT * FROM user_food_records WHERE user_id = #{userId} AND eat_date = #{eatDate}")
    List<UserFoodRecord> findByUserIdAndDate(@Param("userId") Integer userId, @Param("eatDate") LocalDate eatDate);

    @Insert("INSERT INTO user_food_records (user_id, food_name, food_category, quantity, meal_type, eat_date, eat_time, " +
            "total_calories, protein, fat, carbohydrate) " +
            "VALUES (#{userId}, #{foodName}, #{foodCategory}, #{quantity}, #{mealType}, #{eatDate}, #{eatTime}, " +
            "#{totalCalories}, #{protein}, #{fat}, #{carbohydrate})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UserFoodRecord record);

    @Update("UPDATE user_food_records SET food_name = #{foodName}, food_category = #{foodCategory}, " +
            "quantity = #{quantity}, meal_type = #{mealType}, eat_date = #{eatDate}, eat_time = #{eatTime}, " +
            "total_calories = #{totalCalories}, protein = #{protein}, fat = #{fat}, carbohydrate = #{carbohydrate} " +
            "WHERE id = #{id}")
    int update(UserFoodRecord record);

    @Delete("DELETE FROM user_food_records WHERE id = #{id}")
    int deleteById(@Param("id") Integer id);

    @Select("SELECT " +
            "COALESCE(SUM(total_calories), 0) as totalCalories, " +
            "COALESCE(SUM(protein), 0) as totalProtein, " +
            "COALESCE(SUM(fat), 0) as totalFat, " +
            "COALESCE(SUM(carbohydrate), 0) as totalCarbohydrate " +
            "FROM user_food_records " +
            "WHERE user_id = #{userId} AND eat_date = #{eatDate}")
    Map<String, Object> getDailyStats(@Param("userId") Integer userId, @Param("eatDate") LocalDate eatDate);

    @Select("SELECT * FROM user_food_records WHERE user_id = #{userId}")
    List<UserFoodRecord> findByUserId(@Param("userId") Integer userId);
}