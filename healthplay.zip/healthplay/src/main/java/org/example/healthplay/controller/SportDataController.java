package org.example.healthplay.controller;

import org.example.healthplay.entity.SportData;
import org.example.healthplay.service.SportDataService;
import org.example.healthplay.util.Result;
import org.springframework.web.bind.annotation.*;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/api/sport") // 前端请求路径前缀
public class SportDataController {

    @Autowired
    private SportDataService sportDataService;

    // 新增运动数据
    @PostMapping("/add")
    public Result addSportData(@RequestBody SportData sportData) {
        boolean saveFlag = sportDataService.save(sportData);
        if (saveFlag) {
            return Result.success("添加运动数据成功", sportData);
        }
        return Result.error("添加运动数据失败");
    }

    // 查询所有运动数据
    @GetMapping("/list")
    public Result listSportData() {
        try {
            System.out.println("=== 开始查询运动数据 ===");
            List<SportData> list = sportDataService.list();
            System.out.println("查询到的运动数据数量: " + (list != null ? list.size() : 0));
            if (list != null && !list.isEmpty()) {
                System.out.println("第一条数据: " + list.get(0));
            }
            return Result.success("查询成功", list);
        } catch (Exception e) {
            System.err.println("查询运动数据时发生异常: " + e.getMessage());
            e.printStackTrace();
            return Result.error("查询失败: " + e.getMessage());
        }
    }

    // 根据 ID 删除运动数据
    @DeleteMapping("/delete/{id}")
    public Result deleteSportData(@PathVariable Long id) {
        boolean removeFlag = sportDataService.removeById(id);
        if (removeFlag) {
            return Result.success("删除运动数据成功",null);
        }
        return Result.error("删除运动数据失败");
    }

    // 更新运动数据
    @PutMapping("/update")
    public Result updateSportData(@RequestBody SportData sportData) {
        boolean updateFlag = sportDataService.updateById(sportData);
        if (updateFlag) {
            return Result.success("更新运动数据成功", sportData);
        }
        return Result.error("更新运动数据失败");
    }

    // 根据用户ID和日期获取统计信息
    @GetMapping("/stats/{userId}")
    public Result getDailyStats(@PathVariable Long userId, @RequestParam String date) {
        // 这里可以调用service层方法获取统计数据
        // 暂时返回模拟数据
        return Result.success("获取统计信息成功", null);
    }

    // 根据运动类型筛选
    @GetMapping("/type/{userId}")
    public Result getSportDataByType(@PathVariable Long userId, @RequestParam String sportType) {
        // 这里可以调用service层方法根据类型筛选
        // 暂时返回所有数据
        List<SportData> list = sportDataService.list();
        return Result.success("查询成功", list);
    }

    // 获取运动类型列表
    @GetMapping("/types")
    public Result getSportTypes() {
        List<String> types = List.of("跑步", "游泳", "骑行", "健身", "瑜伽", "篮球", "足球", "网球", "羽毛球", "跳绳", "步行");
        return Result.success("获取运动类型成功", types);
    }

}