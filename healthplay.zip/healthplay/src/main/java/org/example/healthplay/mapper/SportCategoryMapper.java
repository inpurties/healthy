package org.example.healthplay.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.example.healthplay.entity.SportCategory;

import java.util.List;

@Mapper
public interface SportCategoryMapper {

    List<SportCategory> getActiveCategories();

    List<SportCategory> getCategoriesByParentId(@Param("parentId") Integer parentId);

    SportCategory getCategoryByCode(@Param("categoryCode") String categoryCode);

    // 新增分类
    int insertCategory(SportCategory category);

    // 更新分类
    int updateCategory(SportCategory category);

    // 删除分类
    int deleteCategory(@Param("id") Integer id);
}