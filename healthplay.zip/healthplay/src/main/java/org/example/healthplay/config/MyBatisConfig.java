//package org.example.healthplay.config;
//
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class MyBatisConfig {
//    // 使用自动配置，不需要手动配置SqlSessionFactory
//}