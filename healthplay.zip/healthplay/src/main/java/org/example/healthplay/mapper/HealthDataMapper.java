package org.example.healthplay.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.example.healthplay.entity.HealthData;

import java.util.List;

@Mapper
public interface HealthDataMapper{

    List<HealthData> selectByUserId(@Param("userId") Integer userId);
}

