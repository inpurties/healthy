package org.example.healthplay.util;
//用于存放工具类相关代码，是项目中通用工具方法的集合
//通常是 Web 相关的配置类，比如可以配置拦截器
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*")  // 支持通配符，允许所有来源
                .allowedMethods("POST", "GET", "PUT", "OPTIONS", "DELETE")
                .maxAge(3600);
        // 注意：不要加 .allowCredentials(true)，否则和 "*" 冲突
    }
}
