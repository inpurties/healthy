package org.example.healthplay.service.impl;

import org.example.healthplay.entity.SportCategory;
import org.example.healthplay.mapper.SportCategoryMapper;
import org.example.healthplay.service.SportCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SportCategoryServiceImpl implements SportCategoryService {

    @Autowired
    private SportCategoryMapper sportCategoryMapper;

    @Override
    public List<SportCategory> getAllActiveCategories() {
        return sportCategoryMapper.getActiveCategories();
    }

    @Override
    public List<SportCategory> getCategoriesByParentId(Integer parentId) {
        return sportCategoryMapper.getCategoriesByParentId(parentId);
    }

    @Override
    public SportCategory getCategoryByCode(String categoryCode) {
        return sportCategoryMapper.getCategoryByCode(categoryCode);
    }

    @Override
    public boolean addCategory(SportCategory category) {
        return sportCategoryMapper.insertCategory(category) > 0;
    }

    @Override
    public boolean updateCategory(SportCategory category) {
        return sportCategoryMapper.updateCategory(category) > 0;
    }

    @Override
    public boolean deleteCategory(Integer id) {
        return sportCategoryMapper.deleteCategory(id) > 0;
    }
}