package org.example.healthplay.service;

import org.example.healthplay.entity.HealthData;

public interface HealthDataService {
    // 根据用户ID获取健康数据
    HealthData getHealthDataByUserId(Integer userId);
}