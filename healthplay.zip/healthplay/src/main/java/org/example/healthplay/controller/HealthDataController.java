package org.example.healthplay.controller;

import org.example.healthplay.entity.HealthData;
import org.example.healthplay.service.HealthDataService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// 修改：使用 jakarta.annotation 包
import jakarta.annotation.Resource;

@RestController
@RequestMapping("/health")
public class HealthDataController {

    @Resource
    private HealthDataService healthDataService;

    @GetMapping("/data/{userId}")
    public HealthData getHealthData(@PathVariable Integer userId) {
        return healthDataService.getHealthDataByUserId(userId);
    }
}