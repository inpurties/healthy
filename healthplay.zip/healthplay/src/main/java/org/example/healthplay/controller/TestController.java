//package org.example.healthplay.controller;
//
//import org.example.healthplay.entity.SportData;
//import org.example.healthplay.service.SportDataService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/api/test")
//public class TestController {
//
//    @Autowired
//    private SportDataService sportDataService;
//
//    @GetMapping("/sport")
//    public String testSportData() {
//        try {
//            System.out.println("=== 测试运动数据查询 ===");
//            long count = sportDataService.count();
//            System.out.println("运动数据总数: " + count);
//            return "运动数据总数: " + count;
//        } catch (Exception e) {
//            System.err.println("查询运动数据时发生异常: " + e.getMessage());
//            e.printStackTrace();
//            return "错误: " + e.getMessage();
//        }
//    }
//}