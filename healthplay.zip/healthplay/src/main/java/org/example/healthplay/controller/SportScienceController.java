package org.example.healthplay.controller;

import org.example.healthplay.entity.SportArticle;
import org.example.healthplay.service.SportArticleService;
import org.example.healthplay.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/sport-science")
public class SportScienceController {

    @Autowired
    private SportArticleService sportArticleService;

    // 获取文章列表
    @GetMapping("/list")
    public Result getArticleList() {
        try {
            Map<String, Object> result = sportArticleService.getPublishedArticles(null, 1, 20);
            return Result.success("获取文章列表成功", result.get("articles"));
        } catch (Exception e) {
            return Result.error("获取文章列表失败: " + e.getMessage());
        }
    }

    // 根据分类获取文章
    @GetMapping("/category/{category}")
    public Result getArticlesByCategory(@PathVariable String category) {
        try {
            // 这里可以根据分类名称筛选文章
            Map<String, Object> result = sportArticleService.getPublishedArticles(null, 1, 20);
            List<SportArticle> articles = (List<SportArticle>) result.get("articles");
            
            // 简单的分类筛选（实际项目中应该根据分类ID筛选）
            List<SportArticle> filteredArticles = articles.stream()
                .filter(article -> article.getTags() != null && article.getTags().contains(category))
                .collect(java.util.stream.Collectors.toList());
            
            return Result.success("获取分类文章成功", filteredArticles);
        } catch (Exception e) {
            return Result.error("获取分类文章失败: " + e.getMessage());
        }
    }

    // 获取推荐文章
    @GetMapping("/recommend")
    public Result getRecommendArticles() {
        try {
            List<SportArticle> articles = sportArticleService.getFeaturedArticles(6);
            return Result.success("获取推荐文章成功", articles);
        } catch (Exception e) {
            return Result.error("获取推荐文章失败: " + e.getMessage());
        }
    }

    // 搜索文章
    @GetMapping("/search")
    public Result searchArticles(@RequestParam String keyword) {
        try {
            Map<String, Object> result = sportArticleService.searchArticlesByTag(keyword, 1, 20);
            return Result.success("搜索文章成功", result.get("articles"));
        } catch (Exception e) {
            return Result.error("搜索文章失败: " + e.getMessage());
        }
    }

    // 获取文章详情
    @GetMapping("/detail/{id}")
    public Result getArticleDetail(@PathVariable Long id) {
        try {
            SportArticle article = sportArticleService.getArticleById(id);
            if (article != null) {
                // 增加浏览次数
                sportArticleService.increaseViewCount(id);
                return Result.success("获取文章详情成功", article);
            } else {
                return Result.error("文章不存在");
            }
        } catch (Exception e) {
            return Result.error("获取文章详情失败: " + e.getMessage());
        }
    }

    // 点赞文章
    @PostMapping("/like/{id}")
    public Result likeArticle(@PathVariable Long id) {
        try {
            boolean success = sportArticleService.increaseLikeCount(id);
            if (success) {
                return Result.success("点赞成功", null);
            } else {
                return Result.error("点赞失败");
            }
        } catch (Exception e) {
            return Result.error("点赞失败: " + e.getMessage());
        }
    }
} 