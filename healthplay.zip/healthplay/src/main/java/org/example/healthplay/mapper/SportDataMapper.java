package org.example.healthplay.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.example.healthplay.entity.SportData;
import java.util.List;

@Mapper
public interface SportDataMapper {
    
    int insert(SportData sportData);
    
    List<SportData> selectAll();
    
    int deleteById(@Param("id") Long id);
    
    int updateById(SportData sportData);
    
    long count();
}