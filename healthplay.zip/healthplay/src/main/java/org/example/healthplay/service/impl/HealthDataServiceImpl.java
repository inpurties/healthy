package org.example.healthplay.service.impl;

import org.example.healthplay.entity.HealthData;
import org.example.healthplay.mapper.HealthDataMapper;
import org.example.healthplay.service.HealthDataService;
// 错误：旧的 javax.annotation 包
// import javax.annotation.Resource;

// 修正：替换为 jakarta.annotation
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HealthDataServiceImpl implements HealthDataService {

    @Resource // 这个注解也需要使用 jakarta 包
    private HealthDataMapper healthDataMapper;

    @Override
    public HealthData getHealthDataByUserId(Integer userId) {
        List<HealthData> healthDataList = healthDataMapper.selectByUserId(userId);
        // 如果列表不为空，返回第一个元素，否则返回null
        return healthDataList != null && !healthDataList.isEmpty() ? healthDataList.get(0) : null;
    }
}