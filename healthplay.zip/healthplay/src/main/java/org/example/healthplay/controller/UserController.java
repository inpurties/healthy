package org.example.healthplay.controller;
//处理用户相关的业务请求，协调业务层和前端的数据交互 。

import org.example.healthplay.entity.QueryInfo;
import org.example.healthplay.entity.User;
import org.example.healthplay.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    UserMapper userMapper;

    @CrossOrigin
    @RequestMapping("/allUser")
    public HashMap<String, Object> getUserList(QueryInfo queryInfo) {
        System.out.println(queryInfo);
        int numbers = userMapper.getUserCounts("%" + queryInfo.getQuery() + "%");
        int pageStart = (queryInfo.getPageNum() - 1) * queryInfo.getPageSize();
        List<User> users = userMapper.getAllUser("%" + queryInfo.getQuery() + "%", pageStart, queryInfo.getPageSize());
        HashMap<String, Object> res = new HashMap<>();
        res.put("numbers", numbers);
        res.put("data", users);
        System.out.println("总条数：" + numbers);
        return res;
    }

    @RequestMapping("/userState")
    public String updateUserState(@RequestParam("id") Integer id,
                                  @RequestParam("state") Boolean state) {
        int i = userMapper.updateState(id, state);
        System.out.println("用户编号:" + id);
        System.out.println("用户状态:" + state);
        return i > 0 ? "success" : "error";
    }

    @RequestMapping("/addUser")
    public String addUser(@RequestBody User user) {
        System.out.println(user);
        user.setRole("普通用户");
        user.setState(false);
        int i = userMapper.addUser(user);
        return i > 0 ? "success" : "error";
    }

    @RequestMapping("/getUpdate")
    public User getUpdateUser(int id) {
        System.out.println("编号:" + id);
        return userMapper.getUpdateUser(id);
    }

    @RequestMapping("/editUser")
    public String editUser(@RequestBody User user) {
        System.out.println(user);
        int i = userMapper.editUser(user);
        return i > 0 ? "success" : "error";
    }

    @RequestMapping("/deleteUser")
    public String deleteUser(int id) {
        System.out.println(id);
        int i = userMapper.deleteUser(id);
        return i > 0 ? "success" : "error";
    }

    @RequestMapping("/setUserRole")
    public String setUserRole(@RequestBody User user) {
        System.out.println("设置用户角色：" + user);
        int i = userMapper.setUserRole(user.getId(), user.getRole());
        return i > 0 ? "success" : "error";
    }
}