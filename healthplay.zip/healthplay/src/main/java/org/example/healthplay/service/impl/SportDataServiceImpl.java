package org.example.healthplay.service.impl;

import org.example.healthplay.entity.SportData;
import org.example.healthplay.mapper.SportDataMapper;
import org.example.healthplay.service.SportDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SportDataServiceImpl implements SportDataService {
    
    @Autowired
    private SportDataMapper sportDataMapper;
    
    @Override
    public boolean save(SportData sportData) {
        return sportDataMapper.insert(sportData) > 0;
    }
    
    @Override
    public List<SportData> list() {
        return sportDataMapper.selectAll();
    }
    
    @Override
    public boolean removeById(Long id) {
        return sportDataMapper.deleteById(id) > 0;
    }
    
    @Override
    public boolean updateById(SportData sportData) {
        return sportDataMapper.updateById(sportData) > 0;
    }
    
    @Override
    public long count() {
        return sportDataMapper.count();
    }
}