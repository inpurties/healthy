package org.example.healthplay.controller;
//controller 接收前端请求
import org.example.healthplay.entity.User;
import org.example.healthplay.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

//import static org.apache.logging.log4j.message.MapMessage.MapFormat.JSON;

@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public String userLogin(@RequestBody User user) {
//        String flag = "error";
        User result = userService.login(user.getUsername(), user.getPassword());

//        HashMap<String, Object> res = new HashMap<>();
//        if (us!=null){
//            flag = "ok";
//        }

//        res.put("flag",flag);
//        res.put("user",user);
//        String res_json = JSON.toJSONString(res);
//        return res;
//
        if (result != null) {
            return "ok";
        } else {
            return "error";
        }
    }
}
