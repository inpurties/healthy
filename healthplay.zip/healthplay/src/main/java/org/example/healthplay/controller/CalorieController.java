package org.example.healthplay.controller;
//提供前端调用的接口，接收前端 HTTP 请求，调用 Service 处理业务，返回响应结果
import org.example.healthplay.entity.FoodNutrition;
import org.example.healthplay.entity.UserFoodRecord;
import org.example.healthplay.service.CalorieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/calorie")
@CrossOrigin(origins = "*")
//允许跨域访问
public class CalorieController {

    @Autowired
    private CalorieService calorieService;

    // 根据餐次获取饮食记录
    @GetMapping("/meal/{userId}")
    public Map<String, Object> getMealRecords(@PathVariable Integer userId,
                                            @RequestParam String mealType,
                                            @RequestParam String date) {
        Map<String, Object> result = new HashMap<>();
        try {
            LocalDate localDate = LocalDate.parse(date);
            List<UserFoodRecord> records = calorieService.getMealRecords(userId, mealType, localDate);
            result.put("code", 200);
            result.put("data", records);
            result.put("message", "获取成功");
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "获取失败: " + e.getMessage());
        }
        return result;
    }

    // 获取每日营养统计
    @GetMapping("/stats/daily/{userId}")
    public Map<String, Object> getDailyStats(@PathVariable Integer userId,
                                           @RequestParam String date) {
        Map<String, Object> result = new HashMap<>();
        try {
            LocalDate localDate = LocalDate.parse(date);
            Map<String, Object> stats = calorieService.getDailyStats(userId, localDate);
            result.put("code", 200);
            result.put("data", stats);
            result.put("message", "获取成功");
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "获取失败: " + e.getMessage());
        }
        return result;
    }

    // 添加饮食记录
    @PostMapping("/add")
    public Map<String, Object> addFoodRecord(@RequestBody UserFoodRecord record) {
        Map<String, Object> result = new HashMap<>();
        try {
            int rows = calorieService.addFoodRecord(record);
            if (rows > 0) {
                result.put("code", 200);
                result.put("message", "添加成功");
            } else {
                result.put("code", 500);
                result.put("message", "添加失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "添加失败: " + e.getMessage());
        }
        return result;
    }

    // 删除饮食记录
    @DeleteMapping("/delete/{id}")
    public Map<String, Object> deleteFoodRecord(@PathVariable Integer id) {
        Map<String, Object> result = new HashMap<>();
        try {
            int rows = calorieService.deleteFoodRecord(id);
            if (rows > 0) {
                result.put("code", 200);
                result.put("message", "删除成功");
            } else {
                result.put("code", 500);
                result.put("message", "删除失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "删除失败: " + e.getMessage());
        }
        return result;
    }

    // 搜索食物
    @GetMapping("/foods/search")
    public Map<String, Object> searchFoods(@RequestParam String foodName) {
        Map<String, Object> result = new HashMap<>();
        try {
            List<FoodNutrition> foods = calorieService.searchFoods(foodName);
            result.put("code", 200);
            result.put("data", foods);
            result.put("message", "搜索成功");
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "搜索失败: " + e.getMessage());
        }
        return result;
    }

    // 获取所有食物
    @GetMapping("/foods/all")
    public Map<String, Object> getAllFoods() {
        Map<String, Object> result = new HashMap<>();
        try {
            List<FoodNutrition> foods = calorieService.getAllFoods();
            result.put("code", 200);
            result.put("data", foods);
            result.put("message", "获取成功");
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "获取失败: " + e.getMessage());
        }
        return result;
    }

    // 根据食物名称获取营养信息
    @GetMapping("/foods/{foodName}")
    public Map<String, Object> getFoodNutrition(@PathVariable String foodName) {
        Map<String, Object> result = new HashMap<>();
        try {
            FoodNutrition food = calorieService.getFoodNutrition(foodName);
            result.put("code", 200);
            result.put("data", food);
            result.put("message", "获取成功");
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "获取失败: " + e.getMessage());
        }
        return result;
    }

    // 更新饮食记录
    @PutMapping("/update")
    public Map<String, Object> updateFoodRecord(@RequestBody UserFoodRecord record) {
        Map<String, Object> result = new HashMap<>();
        try {
            int rows = calorieService.updateFoodRecord(record);
            if (rows > 0) {
                result.put("code", 200);
                result.put("message", "更新成功");
            } else {
                result.put("code", 500);
                result.put("message", "更新失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "更新失败: " + e.getMessage());
        }
        return result;
    }
}