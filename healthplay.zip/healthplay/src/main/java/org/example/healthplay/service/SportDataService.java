package org.example.healthplay.service;

import org.example.healthplay.entity.SportData;
import java.util.List;

public interface SportDataService {
    // 保存运动数据
    boolean save(SportData sportData);
    
    // 获取所有运动数据
    List<SportData> list();
    
    // 根据ID删除运动数据
    boolean removeById(Long id);
    
    // 根据ID更新运动数据
    boolean updateById(SportData sportData);
    
    // 获取运动数据总数
    long count();
}