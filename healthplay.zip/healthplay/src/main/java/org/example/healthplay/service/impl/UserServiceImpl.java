package org.example.healthplay.service.impl;
//接口实现类的存放目录，声明用户业务操作的方法实现接口中定义的业务方法，
//先检查 在加到数据库

import org.example.healthplay.entity.User;
import org.example.healthplay.mapper.UserMapper;
import org.example.healthplay.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User login(String username, String password) {
        User user = userMapper.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}
