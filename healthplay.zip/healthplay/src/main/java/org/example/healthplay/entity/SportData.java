package org.example.healthplay.entity;

import java.time.LocalDate;
import java.time.LocalTime;

public class SportData {
    private Integer id;
    private Integer userId;
    
    private String sportType; // 运动类型，如跑步、跳绳等
    
    private Integer duration; // 运动时长（分钟）
    
    private Integer caloriesBurned; // 消耗卡路里
    
    private Double distance; // 运动距离(公里)
    
    private Integer heartRateAvg; // 平均心率
    
    private Integer heartRateMax; // 最大心率
    
    private String intensityLevel; // 运动强度
    
    private LocalDate sportDate; // 运动日期
    
    private LocalTime startTime; // 开始时间
    
    private LocalTime endTime; // 结束时间
    
    private String notes; // 备注
    
    private LocalDate createdAt;
    
    private LocalDate updatedAt;

    // Getter and Setter methods
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Integer getCaloriesBurned() {
        return caloriesBurned;
    }

    public void setCaloriesBurned(Integer caloriesBurned) {
        this.caloriesBurned = caloriesBurned;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Integer getHeartRateAvg() {
        return heartRateAvg;
    }

    public void setHeartRateAvg(Integer heartRateAvg) {
        this.heartRateAvg = heartRateAvg;
    }

    public Integer getHeartRateMax() {
        return heartRateMax;
    }

    public void setHeartRateMax(Integer heartRateMax) {
        this.heartRateMax = heartRateMax;
    }

    public String getIntensityLevel() {
        return intensityLevel;
    }

    public void setIntensityLevel(String intensityLevel) {
        this.intensityLevel = intensityLevel;
    }

    public LocalDate getSportDate() {
        return sportDate;
    }

    public void setSportDate(LocalDate sportDate) {
        this.sportDate = sportDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDate getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // 添加toString方法用于调试
    @Override
    public String toString() {
        return "SportData{" +
                "id=" + id +
                ", userId=" + userId +
                ", sportType='" + sportType + '\'' +
                ", duration=" + duration +
                ", caloriesBurned=" + caloriesBurned +
                ", distance=" + distance +
                ", heartRateAvg=" + heartRateAvg +
                ", heartRateMax=" + heartRateMax +
                ", intensityLevel='" + intensityLevel + '\'' +
                ", sportDate=" + sportDate +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", notes='" + notes + '\'' +
                '}';
    }
}