package org.example.healthplay.entity;

import java.math.BigDecimal;

public class FoodNutrition {
    private Integer id;
    private String foodName;
    private String foodCategory;
    private BigDecimal caloriesPer100g;
    private BigDecimal protein;
    private BigDecimal fat;
    private BigDecimal carbohydrate;

    // 构造函数
    public FoodNutrition() {}

    public FoodNutrition(String foodName, String foodCategory, BigDecimal caloriesPer100g) {
        this.foodName = foodName;
        this.foodCategory = foodCategory;
        this.caloriesPer100g = caloriesPer100g;
    }

    // Getter and Setter methods
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodCategory() {
        return foodCategory;
    }

    public void setFoodCategory(String foodCategory) {
        this.foodCategory = foodCategory;
    }

    public BigDecimal getCaloriesPer100g() {
        return caloriesPer100g;
    }

    public void setCaloriesPer100g(BigDecimal caloriesPer100g) {
        this.caloriesPer100g = caloriesPer100g;
    }

    public BigDecimal getProtein() {
        return protein;
    }

    public void setProtein(BigDecimal protein) {
        this.protein = protein;
    }

    public BigDecimal getFat() {
        return fat;
    }

    public void setFat(BigDecimal fat) {
        this.fat = fat;
    }

    public BigDecimal getCarbohydrate() {
        return carbohydrate;
    }

    public void setCarbohydrate(BigDecimal carbohydrate) {
        this.carbohydrate = carbohydrate;
    }
}