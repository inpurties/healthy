package org.example.healthplay.service;

import org.example.healthplay.entity.SportCategory;

import java.util.List;

/**
 * 运动分类业务逻辑接口
 */
public interface SportCategoryService {
    
    /**
     * 获取所有启用的分类
     */
    List<SportCategory> getAllActiveCategories();
    
    /**
     * 根据父分类ID获取子分类
     */
    List<SportCategory> getCategoriesByParentId(Integer parentId);
    
    /**
     * 根据分类编码获取分类
     */
    SportCategory getCategoryByCode(String categoryCode);
    
    /**
     * 新增分类
     */
    boolean addCategory(SportCategory category);
    
    /**
     * 更新分类
     */
    boolean updateCategory(SportCategory category);
    
    /**
     * 删除分类（逻辑删除）
     */
    boolean deleteCategory(Integer id);
}