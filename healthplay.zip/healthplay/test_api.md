# 运动知识API测试指南

## 1. 测试分类接口
```bash
# 获取所有运动分类
curl -X GET "http://localhost:9000/api/sport-knowledge/categories"
```

## 2. 测试文章接口
```bash
# 获取文章列表
curl -X GET "http://localhost:9000/api/sport-knowledge/articles?pageNum=1&pageSize=10"

# 获取特定分类的文章
curl -X GET "http://localhost:9000/api/sport-knowledge/articles?categoryId=1&pageNum=1&pageSize=10"

# 获取推荐文章
curl -X GET "http://localhost:9000/api/sport-knowledge/articles/featured?limit=5"
```

## 3. 测试文章详情接口
```bash
# 获取文章详情
curl -X GET "http://localhost:9000/api/sport-knowledge/articles/1"
```

## 4. 浏览器测试
直接在浏览器中访问：
- http://localhost:9000/api/sport-knowledge/categories
- http://localhost:9000/api/sport-knowledge/articles

## 5. 检查数据库
```sql
USE easyproject;
SELECT * FROM sport_categories;
SELECT * FROM sport_articles;
``` 